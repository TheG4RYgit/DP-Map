package e.csf0085.test_frag_app;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button oneButton = (Button) findViewById(R.id.oneButton);
        oneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment oneFrag = new OneFragment();
                getSupportFragmentManager().popBackStack();
                getSupportFragmentManager().beginTransaction().replace(R.id.mainFrame, oneFrag,
                        oneFrag.getClass().getSimpleName()).addToBackStack(null).commit();
            }
        });

        Button twoButton = (Button) findViewById(R.id.twoButton);
        twoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment twoFrag = new TwoFragment();
                getSupportFragmentManager().popBackStack();
                getSupportFragmentManager().beginTransaction().replace(R.id.mainFrame, twoFrag,
                        twoFrag.getClass().getSimpleName()).addToBackStack(null).commit();
            }
        });


 /*       Fragment recFrag = new Recycle();
        //getSupportFragmentManager().popBackStack();
        getSupportFragmentManager().beginTransaction().replace(R.id.sideFrame, recFrag).commit();
*/
        /*Button threeButton = (Button) findViewById(R.id.threeButton);
        threeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment recFrag = new Recycle();
                getSupportFragmentManager().popBackStack();
                getSupportFragmentManager().beginTransaction().replace(R.id.mainFrame, recFrag,
                        recFrag.getClass().getSimpleName()).addToBackStack(null).commit();
            }
         });
         */
    }
}
