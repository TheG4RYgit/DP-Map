package e.csf0085.test_frag_app;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import java.util.List;

//this class has been deprecated from the project.
//originally this was to allow communication between fragments.

public class ClassroomViewModel extends ViewModel {
    private MutableLiveData<List<String>> rooms;

    public MutableLiveData<List<String>> getClassrooms() {
        if (rooms == null) {
            rooms = new MutableLiveData<List<String>>();
            String temp;
            temp = "temp";
            Insert(temp);
        }
        return rooms;
    }

    public void Insert(String data){
        List<String> temp = rooms.getValue();
        temp.add(data);
        rooms.setValue(temp);
    }

    public String getDataAt(int index){
        if(index < rooms.getValue().size())
            return rooms.getValue().get(index);

        return null;
    }

    public int sizeOf(){

        return rooms.getValue().size();
    }

}
