package e.csf0085.test_frag_app;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

//this is the add fragment!

public class  OneFragment extends Fragment implements MyRecyclerViewAdapter.ItemClickListener {

    MyRecyclerViewAdapter adapter;
    private ClassList classRooms;

    // TODO: your onCreate function should look like this. without the @Override tag the system will not
    // TODO: call your onCreate function. also you need to get an instance of a ClassList object here.
    // TODO: classRooms = ClassList.getInstance(); also you shouldn't change the parameters of this function.
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        classRooms = ClassList.getInstance();  //this line gets you an instance of the
                                               //singleton. without this classRooms is a null reference!!
    }

    //stuff for RecyclerView below.
        //this method is an interface to the Adapter class
    @Override
    public void onItemClick(View view, int position) {
        //this bit is just to make sure it works.
        if (isAdded())
            Toast.makeText(getActivity().getApplicationContext(), "You clicked " + adapter.getItem(position) + " on row number " + position, Toast.LENGTH_SHORT).show();
    }


    //stuff for RecyclerView above.

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View parentView = inflater.inflate(R.layout.fragment_one, container, false);

        // find id of actual recyclerView layout
        RecyclerView recyclerView = parentView.findViewById(R.id.rv_sidebar);
        //set up a layout manager for it.
        recyclerView.setLayoutManager(new LinearLayoutManager( getActivity().getApplicationContext() ) );
        //this is just an optimization option.
        recyclerView.setHasFixedSize(true);
        //set up our custom adaptor
        adapter = new MyRecyclerViewAdapter(getActivity().getApplicationContext());
        adapter.setClickListener(this);
        //tell recyclerView to use our adaptor. you use this adapter to tell recyclerView data has been added.
        recyclerView.setAdapter(adapter);

        //@Manny our method of adding is pretty much the same.
        Button AddButton = (Button) parentView.findViewById(R.id.addButton);
        AddButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                EditText text = parentView.findViewById(R.id.editText);
                String roomNum = text.getText().toString();
                if(!roomNum.isEmpty()) {
                    Class temp = new Class('B', Integer.parseInt(roomNum));
                    classRooms.list.add(temp);
                    adapter.notifyDataInsertion(); //this tells recyclerView to draw the new class in the list.
                }else
                    Toast.makeText(getActivity().getApplicationContext(), "failed to add string, is string empty?", Toast.LENGTH_SHORT).show();
            }
        });

        //return the view like we're supposed to.
        return parentView;
    }

}
